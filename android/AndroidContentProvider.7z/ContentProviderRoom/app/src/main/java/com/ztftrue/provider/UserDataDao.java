package com.ztftrue.provider;

import android.database.Cursor;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@SuppressWarnings("unused")
@Dao
public interface UserDataDao {
    @Query("SELECT * FROM UserDataTable")
    List<UserData> getAll();

    @Insert()
    void insertData(UserData treeData);

    @Update
    void updateData(UserData treeData);

    @Query("SELECT * FROM UserDataTable WHERE id > :userId LIMIT 5")
    public Cursor loadRawUsersOlderThan(int userId);

}
