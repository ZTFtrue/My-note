package com.ztftrue.provider;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "finch.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 创建表, 如果不存在
        db.execSQL("CREATE TABLE IF NOT EXISTS "+ MyContentProvider.TABLE_NAME + "("+ MyContentProvider.COLUMN_ID +" INTEGER PRIMARY KEY AUTOINCREMENT," + MyContentProvider.COLUMN_NAME +" VARCHAR NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 表升级,删除原来的表, 可以选择备份
        db.execSQL("DROP TABLE IF EXISTS "+ MyContentProvider.TABLE_NAME+";");
        onCreate(db);
    }
}
