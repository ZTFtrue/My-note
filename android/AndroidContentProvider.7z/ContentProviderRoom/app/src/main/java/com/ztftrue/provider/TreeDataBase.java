package com.ztftrue.provider;

import androidx.room.Database;
import androidx.room.RoomDatabase;


@Database(entities = {UserData.class}, version = 1, exportSchema = false)
public abstract class TreeDataBase extends RoomDatabase {
    public abstract UserDataDao treeDataDao();



}
