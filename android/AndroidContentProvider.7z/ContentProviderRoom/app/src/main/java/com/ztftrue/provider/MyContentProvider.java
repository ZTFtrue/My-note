package com.ztftrue.provider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.room.Room;

public class MyContentProvider extends ContentProvider {
    public static final String TABLE_NAME = "user_table";
    public static final String TABLE_NAME_IMG = "user_table";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name";
    // Manifest authorities 必须和这里一致
    public static final String AUTHORITY = MyContentProvider.class.getName();
    public static final int ITEM = 1;
    public static final int ITEM_ID = 2;
    public static final int ITEM_IMG = 3;
    public static final String CONTENT_TYPE = "vnd.android.cursor.dir/user";
    public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/user";

    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/"+TABLE_NAME);
    public static final Uri CONTENT_URI_IMG = Uri.parse("content://" + AUTHORITY + "/"+TABLE_NAME_IMG);

    // The UriMatcher class is helpful for parsing URIs
    // Creates a UriMatcher object. 可以用来区分数据源
    private static final UriMatcher mMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    DBHelper mDbHelper = null;
    SQLiteDatabase db = null;
    // Defines a handle to the Room database
    private TreeDataBase appDatabase;
    // Defines a Data Access Object to perform the database operations
    private UserDataDao userDao;
    // Defines the database name

    static {
        // 注册 uri
        /*
         * The calls to addURI() go here, for all of the content URI patterns that the provider
         * should recognize. For this snippet, only the calls for table 3 are shown.
         */

        /*
         * Sets the integer value for multiple rows in table 3 to 1. Notice that no wildcard is used
         * in the path
         */

        mMatcher.addURI(AUTHORITY, TABLE_NAME, ITEM);
        mMatcher.addURI(AUTHORITY, TABLE_NAME_IMG, ITEM_IMG); // 对应 CONTENT_URI_IMG
        /*
         * Sets the code for a single row to 2. In this case, the "#" wildcard is
         * used. "content://com.example.app.provider/table3/3" matches, but
         * "content://com.example.app.provider/table3 doesn't.
         */
        mMatcher.addURI(AUTHORITY, TABLE_NAME + "/#", ITEM_ID);


    }

    /**
     * 所有这些方法（onCreate() 除外）均可由多个线程同时调用，因此它们必须是线程安全的方法。
     * <p>
     * 避免在 onCreate() 中执行冗长的操作。将初始化任务推迟到实际需要时执行
     *
     * @return success == true
     */
    @Override
    public boolean onCreate() {
        mDbHelper = new DBHelper(getContext());
        db = mDbHelper.getReadableDatabase();
        appDatabase = Room.databaseBuilder(getContext(), TreeDataBase.class, getContext().getFilesDir() + "user_auto").build();
        userDao = appDatabase.treeDataDao();
        return true;
    }

    /**
     * @param uri
     * @param projection
     * @param selection
     * @param selectionArgs
     * @param sortOrder
     * @return 必须返回 Cursor 对象, 如果失败，系统会抛出 Exception.
     * 如果使用 SQLite 数据库作为数据存储，则只需返回由 SQLiteDatabase
     * 类的某个 query() 方法返回的 Cursor.
     * 如果查询不匹配任何行，则您应该返回一个 Cursor 实例（其 getCount() 方法返回 0）
     * 只有当查询过程中出现内部错误时，您才应该返回 null
     * <p>
     * 如果您不使用 SQLite 数据库作为数据存储，请使用 Cursor 的某个具体子类。
     * 例如，在 MatrixCursor 类实现的游标中，每行都是一个 Object 数组。对于此类，请使用 addRow() 来添加新行。
     * <p>
     * Android 系统必须能够跨进程边界传达 Exception。
     * Android 可以为以下异常执行此操作，这些异常可能有助于处理查询错误：
     * IllegalArgumentException（您可以选择在提供程序收到无效的内容 URI 时抛出此异常）
     * NullPointerException
     */
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        MatrixCursor matrixCursor = new MatrixCursor(projection);
        // 需要开启异步线程？？？
//        Cursor cursor = userDao.loadRawUsersOlderThan(1);
//        return  cursor;
//        matrixCursor.addRow(userDao.getAll());
//        return  matrixCursor;
        Cursor c = null;
        /*
         * 另一个类 ContentUris 会提供一些便利方法，
         * 用于处理内容 URI 的 id 部分。
         * Uri 类和 Uri.Builder 类包含一些便利方法，
         * 用于解析现有 Uri 对象和构建新对象。
         */
        switch (mMatcher.match(uri)) {
            case ITEM:
                c = db.query(TABLE_NAME, projection, selection, selectionArgs, null, null, sortOrder);
                break;
            case ITEM_ID:
                c = db.query(TABLE_NAME, projection, COLUMN_ID + "=" + uri.getLastPathSegment(), selectionArgs, null, null, sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI" + uri);
        }
        c.setNotificationUri(getContext().getContentResolver(), uri);
        return c;
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        // 根据匹配规则返回对应的类型
        switch (mMatcher.match(uri)) {
            case ITEM:
                return CONTENT_TYPE;
            case ITEM_ID:
                return CONTENT_ITEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI" + uri);
        }


    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        long rowId;
        Log.d(this.getClass().getName(), String.valueOf(mMatcher.match(uri)));
//        if (mMatcher.match(uri) != ITEM) {
//            throw new IllegalArgumentException("Unknown URI" + uri);
//        }
        rowId = db.insert(TABLE_NAME, null, values);
        if (rowId > 0) {
            Uri noteUri = ContentUris.withAppendedId(CONTENT_URI, rowId);
            getContext().getContentResolver().notifyChange(noteUri, null);
            return noteUri;
        }
        throw new SQLException("Failed to insert row into " + uri);
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection, @Nullable String[] selectionArgs) {
        return 0;
    }
}
