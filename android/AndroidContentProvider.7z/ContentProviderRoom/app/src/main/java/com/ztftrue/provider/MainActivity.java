package com.ztftrue.provider;

import static com.ztftrue.provider.MyContentProvider.ITEM;
import static com.ztftrue.provider.MyContentProvider.TABLE_NAME;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Context context;
    TextView textView;
    private ContentResolver mContentResolver = null;
    private Cursor cursor = null;

    // https://developer.android.com/guide/topics/providers/content-providers
    @SuppressLint({"SetTextI18n", "SoonBlockedPrivateApi"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent();
        intent.setDataAndType(Uri.parse("ztftrue://ztftrue.com"), "image/png");
        intent.setAction(MyContentProvider.class.getName());
        textView = findViewById(R.id.textView);
        context = this;
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContentResolver = getContentResolver();
                for (int i = 0; i < 10; i++) {// 插入 10 条
                    ContentValues values = new ContentValues();
                    values.put(MyContentProvider.COLUMN_NAME, "110110" + i);
                    mContentResolver.insert(MyContentProvider.CONTENT_URI, values);
                    // 这个地址就可以放到另外一个数据库
//                    mContentResolver.insert(MyContentProvider.CONTENT_URI_IMG, values);
                }
                cursor = mContentResolver.query(MyContentProvider.CONTENT_URI, new String[]{MyContentProvider.COLUMN_ID, MyContentProvider.COLUMN_NAME}, null, null, null);
                if (null == cursor) {

                } else if (cursor.getCount() < 1) {
                    /*
                     * Insert code here to notify the user that the search was unsuccessful. This isn't necessarily
                     * an error. You may want to offer the user the option to insert a new row, or re-type the
                     * search term.
                     */
                } else {
//                    cursor.moveToNext()
                    // Insert code here to do something with the results
                    if (cursor.moveToFirst()) {
                        int a = cursor.getColumnIndex(MyContentProvider.COLUMN_NAME);
                        String s = cursor.getString(a);
                        Log.d(MainActivity.class.getName(),s);
                    }
                }
            }
        });
        findViewById(R.id.textView2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setDataAndType(Uri.parse("ztftrue://ztftrue.com"), "image/png");
                intent.setAction(MyContentProvider.class.getName());

            }
        });
    }
}