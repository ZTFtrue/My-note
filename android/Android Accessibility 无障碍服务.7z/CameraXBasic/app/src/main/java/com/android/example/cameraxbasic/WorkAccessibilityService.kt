package com.android.example.cameraxbasic

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.graphics.PixelFormat
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.lifecycleScope
import com.android.example.cameraxbasic.databinding.ActivityFloatItemBinding
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

typealias LumaListener = (luma: Double) -> Unit

class WorkAccessibilityService : AccessibilityService(), LifecycleOwner {
    private lateinit var windowManager: WindowManager
    private var floatRootView: View? = null//悬浮窗View
    private val mLifecycleRegistry = LifecycleRegistry(this)
    override fun onCreate() {
        super.onCreate()
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        initObserve()
    }


    /**
     * 打开关闭的订阅
     */
    private fun initObserve() {
        MainViewModel.isShowWindow.observe(this) {
            if (it) {
                if (floatRootView == null)
                    showWindow()
            } else {
                windowManager.removeView(floatRootView)
            }
        }

    }

//    override fun onGesture(gestureEvent: AccessibilityGestureEvent): Boolean {
////            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)//截图
//        val motionEvents: List<MotionEvent> = gestureEvent.motionEvents
//        if (motionEvents.isNotEmpty()) {
//            val motionEvent1: MotionEvent = motionEvents[0]
//            Log.d("TAG-a", motionEvent1.action.toString())
//            Log.d("TAG-s", motionEvent1.size.toString())
//            val path = Path()//创建Path对象
//            path.moveTo(motionEvent1.x, motionEvent1.y)//要点击的点的坐标
////        如果是单击的话clickTime就设为1,长按就设为500，单位是毫秒
//            val clickTime = 200L
////var clickTime=500
//            val gestureDescription = GestureDescription.Builder()
//                .addStroke(GestureDescription.StrokeDescription(path, 0, clickTime))
//                .build()
//            dispatchGesture(gestureDescription, null, null)
//        }
//        onGesture(gestureEvent.gestureId)
//        return false
//    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showWindow() {
        // 设置LayoutParam
        // 获取WindowManager服务
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val outMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(outMetrics)
        val layoutParam = WindowManager.LayoutParams()
        layoutParam.apply {
            //显示的位置
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
            //刘海屏延伸到刘海里面
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            flags =
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            format = PixelFormat.TRANSPARENT
        }
        val ac: ActivityFloatItemBinding =
            ActivityFloatItemBinding.inflate(LayoutInflater.from(this))
        floatRootView = ac.root
        // AppCompatImageView
//        one?.setOnClickListener { _ ->
//            run {
//                performGlobalAction(GLOBAL_ACTION_BACK)//模拟back键
//            }
//        }
//        two?.setOnClickListener { _ ->
//            run {
//                performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)//截图
//            }
//        }
//        one?.setOnLongClickListener { _ ->
//            if (floatRootView != null) {
//                one.visibility = View.GONE
//                move?.visibility = View.VISIBLE
//                windowManager.updateViewLayout(floatRootView, floatRootView!!.layoutParams)
//                val vibratorManager: VibratorManager =
//                    this.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
//                val vibrationWaveFormDurationPattern =
//                    longArrayOf(0, 10)
//                val vibrationEffect =
//                    VibrationEffect.createWaveform(vibrationWaveFormDurationPattern, -1)
//                vibratorManager.vibrate(CombinedVibration.createParallel(vibrationEffect))
//            }
//            false
//        }
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)

        floatRootView?.setOnClickListener { _ ->
            run {
                val intent =
                    Intent(this@WorkAccessibilityService, CameraActivity::class.java);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                this@WorkAccessibilityService.startActivity(intent)
            }
        }
        floatRootView?.setOnTouchListener(
            ItemViewTouchListener(
                layoutParam,
                windowManager,
                outMetrics.widthPixels,
                this@WorkAccessibilityService
            )
        )
        windowManager.addView(floatRootView, layoutParam)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
    }

    override fun getLifecycle(): Lifecycle = mLifecycleRegistry

    override fun onUnbind(intent: Intent?): Boolean {
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        mLifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    }

    override fun onInterrupt() {
    }

    private lateinit var cameraExecutor: ExecutorService

    fun capture() {

        // Initialize our background executor
        cameraExecutor = Executors.newSingleThreadExecutor()


        // Set up the intent filter that will receive events from our main activity

        // Every time the orientation of device changes, update rotation for use cases

        // Initialize WindowManager to retrieve display metrics


        // Set up the camera and its use cases
        lifecycleScope.launch {
            setUpCamera()
        }
    }

    private var cameraProvider: ProcessCameraProvider? = null
    private var lensFacing: Int = CameraSelector.LENS_FACING_BACK
    private var preview: Preview? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private var camera: Camera? = null
    private var TAG = "camera"
    private fun setUpCamera() {
        cameraProvider =
            ProcessCameraProvider
                .getInstance(this@WorkAccessibilityService)
                .get()
        lensFacing = when {
            hasBackCamera() -> CameraSelector.LENS_FACING_BACK
            hasFrontCamera() -> CameraSelector.LENS_FACING_FRONT
            else -> throw IllegalStateException("Back and front camera are unavailable")
        }
        bindCameraUseCases()
    }

    /** Declare and bind preview, capture and analysis use cases */
    private fun bindCameraUseCases() {

        // Get screen metrics used to setup camera for full screen resolution
        val metrics = windowManager.getCurrentWindowMetrics().bounds
        Log.d(TAG, "Screen metrics: ${metrics.width()} x ${metrics.height()}")

        val screenAspectRatio = aspectRatio(metrics.width(), metrics.height())
        Log.d(TAG, "Preview aspect ratio: $screenAspectRatio")


        // CameraProvider
        val cameraProvider = cameraProvider
            ?: throw IllegalStateException("Camera initialization failed.")

        // CameraSelector
        val cameraSelector = CameraSelector.Builder().requireLensFacing(lensFacing).build()

        // Preview
        preview = Preview.Builder()
            // We request aspect ratio but no resolution
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation
//            .setTargetRotation(rotation)
            .build()

        // ImageCapture
        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            // We request aspect ratio but no resolution to match preview config, but letting
            // CameraX optimize for whatever specific resolution best fits our use cases
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation, we will have to call this again if rotation changes
            // during the lifecycle of this use case
//            .setTargetRotation(rotation)
            .build()

        // ImageAnalysis
        imageAnalyzer = ImageAnalysis.Builder()
            // We request aspect ratio but no resolution
            .setTargetAspectRatio(screenAspectRatio)
            // Set initial target rotation, we will have to call this again if rotation changes
            // during the lifecycle of this use case
//            .setTargetRotation(rotation)
            .build()
            // The analyzer can then be assigned to the instance
            .also {
                it.setAnalyzer(cameraExecutor, LuminosityAnalyzer { luma ->
                    // Values returned from our analyzer are passed to the attached listener
                    // We log image analysis results here - you should do something useful
                    // instead!
                    Log.d(TAG, "Average luminosity: $luma")
                })
            }

        // Must unbind the use-cases before rebinding them
        cameraProvider.unbindAll()

        if (camera != null) {
            // Must remove observers from the previous camera instance
            // removeCameraStateObservers(camera!!.cameraInfo)
        }

        try {
            // A variable number of use-cases can be passed here -
            // camera provides access to CameraControl & CameraInfo
            camera = cameraProvider.bindToLifecycle(
                this, cameraSelector, preview, imageCapture, imageAnalyzer
            )

            // Attach the viewfinder's surface provider to preview use case
            // preview?.setSurfaceProvider(fragmentCameraBinding.viewFinder.surfaceProvider)
            observeCameraState(camera?.cameraInfo!!)
        } catch (exc: Exception) {
            Log.e(TAG, "Use case binding failed", exc)
        }


    }

    private fun observeCameraState(cameraInfo: CameraInfo) {
//        cameraInfo.cameraState.observe(viewLifecycleOwner) { cameraState ->
//            run {
//                when (cameraState.type) {
//                    CameraState.Type.PENDING_OPEN -> {
//                        // Ask the user to close other camera apps
//                        Toast.makeText(this,
//                            "CameraState: Pending Open",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.Type.OPENING -> {
//                        // Show the Camera UI
//                        Toast.makeText(this@WorkAccessibilityService,
//                            "CameraState: Opening",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.Type.OPEN -> {
//                        // Setup Camera resources and begin processing
//                        Toast.makeText(this@WorkAccessibilityService,
//                            "CameraState: Open",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.Type.CLOSING -> {
//                        // Close camera UI
//                        Toast.makeText(this@WorkAccessibilityService,
//                            "CameraState: Closing",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.Type.CLOSED -> {
//                        // Free camera resources
//                        Toast.makeText(this@WorkAccessibilityService,
//                            "CameraState: Closed",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                }
//            }
//
//            cameraState.error?.let { error ->
//                when (error.code) {
//                    // Open errors
//                    CameraState.ERROR_STREAM_CONFIG -> {
//                        // Make sure to setup the use cases properly
//                        Toast.makeText(this,
//                            "Stream config error",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    // Opening errors
//                    CameraState.ERROR_CAMERA_IN_USE -> {
//                        // Close the camera or ask user to close another camera app that's using the
//                        // camera
//                        Toast.makeText(this,
//                            "Camera in use",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.ERROR_MAX_CAMERAS_IN_USE -> {
//                        // Close another open camera in the app, or ask the user to close another
//                        // camera app that's using the camera
//                        Toast.makeText(this,
//                            "Max cameras in use",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.ERROR_OTHER_RECOVERABLE_ERROR -> {
//                        Toast.makeText(this,
//                            "Other recoverable error",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    // Closing errors
//                    CameraState.ERROR_CAMERA_DISABLED -> {
//                        // Ask the user to enable the device's cameras
//                        Toast.makeText(this,
//                            "Camera disabled",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    CameraState.ERROR_CAMERA_FATAL_ERROR -> {
//                        // Ask the user to reboot the device to restore camera function
//                        Toast.makeText(this,
//                            "Fatal error",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                    // Closed errors
//                    CameraState.ERROR_DO_NOT_DISTURB_MODE_ENABLED -> {
//                        // Ask the user to disable the "Do Not Disturb" mode, then reopen the camera
//                        Toast.makeText(this,
//                            "Do not disturb mode enabled",
//                            Toast.LENGTH_SHORT).show()
//                    }
//                }
//            }
//        }
    }

    fun take() {
        // Get a stable reference of the modifiable image capture use case
        imageCapture?.let { imageCapture ->
            // Create time stamped name and MediaStore entry.
            val name = SimpleDateFormat(FILENAME, Locale.US)
                .format(System.currentTimeMillis())
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, PHOTO_TYPE)
                val appName = this@WorkAccessibilityService.resources.getString(R.string.app_name)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/${appName}")
            }

            // Create output options object which contains file + metadata
            val outputOptions = ImageCapture.OutputFileOptions
                .Builder(
                    this.contentResolver,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                .build()

            // Setup image capture listener which is triggered after photo has been taken
            imageCapture.takePicture(
                outputOptions, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
                    override fun onError(exc: ImageCaptureException) {
                        Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                    }

                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        val savedUri = output.savedUri
                        Log.d(TAG, "Photo capture succeeded: $savedUri")


                        // Implicit broadcasts will be ignored for devices running API level >= 24
                        // so if you only target API level 24+ you can remove this statement
                    }
                })
        }
    }

    /** Returns true if the device has an available back camera. False otherwise */
    private fun hasBackCamera(): Boolean {
        return cameraProvider?.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) ?: false
    }

    /** Returns true if the device has an available front camera. False otherwise */
    private fun hasFrontCamera(): Boolean {
        return cameraProvider?.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA) ?: false
    }

    companion object {
        private const val TAG = "CameraXBasic"
        private const val FILENAME = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val PHOTO_TYPE = "image/jpeg"
        private const val RATIO_4_3_VALUE = 4.0 / 3.0
        private const val RATIO_16_9_VALUE = 16.0 / 9.0
    }

    private fun aspectRatio(width: Int, height: Int): Int {
        val previewRatio = max(width, height).toDouble() / min(width, height)
        if (abs(previewRatio - RATIO_4_3_VALUE) <= abs(previewRatio - RATIO_16_9_VALUE)) {
            return AspectRatio.RATIO_4_3
        }
        return AspectRatio.RATIO_16_9
    }

    private class LuminosityAnalyzer(listener: LumaListener? = null) : ImageAnalysis.Analyzer {
        private val frameRateWindow = 8
        private val frameTimestamps = ArrayDeque<Long>(5)
        private val listeners = ArrayList<LumaListener>().apply { listener?.let { add(it) } }
        private var lastAnalyzedTimestamp = 0L
        var framesPerSecond: Double = -1.0
            private set

        /**
         * Helper extension function used to extract a byte array from an image plane buffer
         */
        private fun ByteBuffer.toByteArray(): ByteArray {
            rewind()    // Rewind the buffer to zero
            val data = ByteArray(remaining())
            get(data)   // Copy the buffer into a byte array
            return data // Return the byte array
        }

        /**
         * Analyzes an image to produce a result.
         *
         * <p>The caller is responsible for ensuring this analysis method can be executed quickly
         * enough to prevent stalls in the image acquisition pipeline. Otherwise, newly available
         * images will not be acquired and analyzed.
         *
         * <p>The image passed to this method becomes invalid after this method returns. The caller
         * should not store external references to this image, as these references will become
         * invalid.
         *
         * @param image image being analyzed VERY IMPORTANT: Analyzer method implementation must
         * call image.close() on received images when finished using them. Otherwise, new images
         * may not be received or the camera may stall, depending on back pressure setting.
         *
         */
        override fun analyze(image: ImageProxy) {
            // If there are no listeners attached, we don't need to perform analysis
            if (listeners.isEmpty()) {
                image.close()
                return
            }

            // Keep track of frames analyzed
            val currentTime = System.currentTimeMillis()
            frameTimestamps.push(currentTime)

            // Compute the FPS using a moving average
            while (frameTimestamps.size >= frameRateWindow) frameTimestamps.removeLast()
            val timestampFirst = frameTimestamps.peekFirst() ?: currentTime
            val timestampLast = frameTimestamps.peekLast() ?: currentTime
            framesPerSecond = 1.0 / ((timestampFirst - timestampLast) /
                    frameTimestamps.size.coerceAtLeast(1).toDouble()) * 1000.0

            // Analysis could take an arbitrarily long amount of time
            // Since we are running in a different thread, it won't stall other use cases

            lastAnalyzedTimestamp = frameTimestamps.first

            // Since format in ImageAnalysis is YUV, image.planes[0] contains the luminance plane
            val buffer = image.planes[0].buffer

            // Extract image data from callback object
            val data = buffer.toByteArray()

            // Convert the data into an array of pixel values ranging 0-255
            val pixels = data.map { it.toInt() and 0xFF }

            // Compute average luminance for the image
            val luma = pixels.average()

            // Call all listeners with new value
            listeners.forEach { it(luma) }

            image.close()
        }
    }

}