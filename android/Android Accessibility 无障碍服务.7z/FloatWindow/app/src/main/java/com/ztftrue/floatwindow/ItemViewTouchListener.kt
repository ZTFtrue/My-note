package com.ztftrue.floatwindow

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

class ItemViewTouchListener(
    private val wl: WindowManager.LayoutParams,
    private val windowManager: WindowManager,
    private val screenWidth: Int,
    private val workAccessibilityService: WorkAccessibilityService
) : View.OnTouchListener {
    private var x = 0
    private var y = 0

    private var xStart = 0
    private var yStart = 0

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        when (motionEvent.action) {
            MotionEvent.ACTION_DOWN -> {
                x = motionEvent.rawX.toInt()
                y = motionEvent.rawY.toInt()
                xStart = motionEvent.rawX.toInt()
                yStart = motionEvent.rawY.toInt()
            }
            MotionEvent.ACTION_MOVE -> {
                val nowX = motionEvent.rawX.toInt()
                val nowY = motionEvent.rawY.toInt()
                val movedX = nowX - x
                val movedY = nowY - y
                x = nowX
                y = nowY
                wl.apply {
                    x += movedX
                    y += movedY
                }
                //更新悬浮球控件位置
                windowManager.updateViewLayout(view, wl)
            }
            MotionEvent.ACTION_UP -> {
                val nowX = motionEvent.rawX.toInt()
                val nowY = motionEvent.rawY.toInt()
                if (nowX == xStart && nowY == yStart) {
//                    workAccessibilityService.performGlobalAction(GLOBAL_ACTION_BACK)
//                    val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
////                    takePictureIntent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
//                    takePictureIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                    workAccessibilityService.startActivity(takePictureIntent)
//                    val intent = Intent()
//                    val cn = ComponentName("com.android.camera", "com.android.camera.Camera")
//                    intent.component = cn
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//                    workAccessibilityService.startActivity(intent)
                } else {
                    x = nowX
                    val movedX: Int = if (nowX > screenWidth / 2)
                        screenWidth / 2
                    else {
                        -screenWidth / 2
                    }
                    wl.x = movedX
                    //更新悬浮球控件位置
                    windowManager.updateViewLayout(view, wl)
                }

            }
            else -> {

            }
        }
        return false
    }

}