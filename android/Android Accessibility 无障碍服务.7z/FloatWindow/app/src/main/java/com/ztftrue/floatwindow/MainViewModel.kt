package com.ztftrue.floatwindow

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

object MainViewModel : ViewModel() {
    //悬浮窗口创建 移除  基于无障碍服务
    var isShowWindow = MutableLiveData<Boolean>()
    // 控制 移动view 显示
    var switchView = MutableLiveData<Boolean>()
}